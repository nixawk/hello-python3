#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from app import APP


if __name__ == '__main__':
    application = APP()
    application.run()
