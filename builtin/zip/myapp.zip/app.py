# -*- coding: utf-8 -*-

class APP(object):

    def run(self):
        print("app is started")
